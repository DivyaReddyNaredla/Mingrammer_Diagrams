#!/bin/bash
GIT_USER=mingrammer CURRENT_BRANCH=master USE_SSH=true yarn run publish-gh-pages
